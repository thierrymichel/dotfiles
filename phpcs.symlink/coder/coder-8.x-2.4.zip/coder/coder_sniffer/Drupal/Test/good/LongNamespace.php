<?php

/**
 * @file
 * Contains \Drupal\random\bunny\hat\long\namingspace\wtf\still\going\strong\LongNamespace.php.
 */

namespace Drupal\random\bunny\hat\long\namingspace\wtf\still\going\strong;

/**
 * Some fluffy comment about the class.
 */
class LongNamespace {

}
