alert('some code here and then exactly one newline');
