alert('some code here and then two newlines');

